const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./licenses.db');
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS licenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT UNIQUE NOT NULL,
      device_id TEXT,
      notes TEXT,
      issued_at TEXT DEFAULT (datetime('now')),
      expires_at TEXT,
      is_blocked INTEGER DEFAULT 0,
      use_count INTEGER DEFAULT 0
    )
  `, (err) => {
    if (err) console.error('Error creating table:', err);
    else console.log('Table "licenses" ready.');
  });
});
db.close();
