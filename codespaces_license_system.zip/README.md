# Codespaces License Server (Ready)

This project is a ready-to-run license server designed for GitHub Codespaces (or any container / VPS).
It uses Node.js + Express + SQLite and serves both the Admin UI and the User UI.

Quick start (Codespaces)
1. Push this repository to GitHub.
2. Open repository in GitHub Codespaces (click Code → Open with Codespaces).
3. Codespaces will run `postCreateCommand` which installs dependencies and runs DB init.
4. Start the server if not already running: `npm start`.
5. Open forwarded port (3000) using Codespaces preview URL.

Admin credentials (preconfigured)
- Username: HK Devloper
- Password: Alone@7

API base path
All API endpoints are served under the base path /license-api. Examples:
- Login: POST /license-api/login
- Generate license (admin): POST /license-api/licenses (Authorization: Bearer <token>)
- Validate: POST /license-api/validate

Files of interest
- server.js — main server
- init_db.js — initializes SQLite DB file licenses.db
- public/ — user and admin UI
- .devcontainer/devcontainer.json — Codespaces auto-setup (runs npm install && npm run initdb)

Run locally (no Codespaces)
1. Install Node.js (v16+).
2. npm install
3. npm run initdb
4. npm start
5. Open http://localhost:3000/ (user) and http://localhost:3000/admin.html (admin)

Security notes
- Change ADMIN_TOKEN_SECRET in .env before exposing publicly.
- Use HTTPS and a reverse proxy in production.
- Back up licenses.db regularly.
