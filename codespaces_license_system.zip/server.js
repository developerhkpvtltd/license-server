require('dotenv').config();
const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const helmet = require('helmet');
const cors = require('cors');

const app = express();
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const API_BASE = process.env.API_BASE || '/license-api';
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const ADMIN_USER = process.env.ADMIN_USER || 'HK Devloper';
const ADMIN_PASS = process.env.ADMIN_PASS || 'Alone@7';
const ADMIN_TOKEN_SECRET = process.env.ADMIN_TOKEN_SECRET || 'change_this_long_secret_please_replace';
const ADMIN_TOKEN_EXPIRES = process.env.ADMIN_TOKEN_EXPIRES || '2h';
const SITE_URL = process.env.SITE_URL || 'http://localhost:3000';

app.use(cors({ origin: true, optionsSuccessStatus: 204 }));

const DB_FILE = path.join(__dirname, 'licenses.db');
const db = new sqlite3.Database(DB_FILE);

// Helper: generate license key
function genKey() {
  const id = uuidv4().replace(/-/g,'').toUpperCase();
  return `${id.substr(0,4)}-${id.substr(4,4)}-${id.substr(8,4)}-${id.substr(12,4)}`;
}

// Helper: create admin JWT
function createAdminToken(username) {
  return jwt.sign({ user: username, role: 'admin' }, ADMIN_TOKEN_SECRET, { expiresIn: ADMIN_TOKEN_EXPIRES });
}

// Middleware: verify admin JWT (Authorization: Bearer <token>)
function verifyAdminJWT(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ success:false, message:'Missing authorization header' });
  const parts = auth.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') return res.status(401).json({ success:false, message:'Invalid authorization header' });
  const token = parts[1];
  try {
    const decoded = jwt.verify(token, ADMIN_TOKEN_SECRET);
    if (decoded.role === 'admin') { req.admin = decoded; return next(); }
    return res.status(403).json({ success:false, message:'Not an admin token' });
  } catch(err) {
    return res.status(401).json({ success:false, message:'Invalid or expired token' });
  }
}

// Serve static UI from /public
app.use('/', express.static(path.join(__dirname, 'public')));

// Health check
app.get(API_BASE + '/ping', (req, res) => res.json({ success:true, ts: new Date().toISOString() }));

// Admin login
app.post(API_BASE + '/login', (req, res) => {
  const { user, pass } = req.body || {};
  if (!user || !pass) return res.status(400).json({ success:false, message:'Missing credentials' });
  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    const token = createAdminToken(user);
    return res.json({ success:true, token, expiresIn: ADMIN_TOKEN_EXPIRES });
  }
  return res.status(401).json({ success:false, message:'Invalid credentials' });
});

// Admin: list licenses
app.get(API_BASE + '/licenses', verifyAdminJWT, (req, res) => {
  const q = req.query.q || '';
  const limit = parseInt(req.query.limit||'100',10);
  const offset = parseInt(req.query.offset||'0',10);
  let sql = 'SELECT id, key, device_id, notes, issued_at, expires_at, is_blocked, use_count FROM licenses';
  const params = [];
  if (q) {
    sql += ' WHERE key LIKE ? OR device_id LIKE ? OR notes LIKE ?';
    const like = `%${q}%`;
    params.push(like, like, like);
  }
  sql += ' ORDER BY issued_at DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);
  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ success:false, message: err.message });
    const countSql = q ? 'SELECT COUNT(*) as c FROM licenses WHERE key LIKE ? OR device_id LIKE ? OR notes LIKE ?' : 'SELECT COUNT(*) as c FROM licenses';
    const cparams = q ? [ `%${q}%`, `%${q}%`, `%${q}%` ] : [];
    db.get(countSql, cparams, (err2, row) => {
      const total = (row && row.c) ? row.c : 0;
      res.json({ success:true, total, rows });
    });
  });
});

// Admin: create license
app.post(API_BASE + '/licenses', verifyAdminJWT, (req, res) => {
  const days = parseInt(req.body.days || '7', 10);
  const notes = req.body.notes || null;
  const device_id = req.body.device_id || null;
  const key = genKey();
  const expires_at = days > 0 ? new Date(Date.now() + days*24*60*60*1000).toISOString() : null;
  db.run('INSERT INTO licenses (key, device_id, notes, expires_at) VALUES (?,?,?,?)', [key, device_id, notes, expires_at], function(err){
    if (err) return res.status(500).json({ success:false, message: err.message });
    res.json({ success:true, id: this.lastID, key, device_id, expires_at });
  });
});

// Admin: update license (block/unblock/delete/update)
app.put(API_BASE + '/licenses/:id', verifyAdminJWT, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!id) return res.status(400).json({ success:false, message:'Missing id' });
  const { action, expires_at, device_id, notes } = req.body;
  if (action === 'block' || action === 'unblock') {
    const is_blocked = action === 'block' ? 1 : 0;
    db.run('UPDATE licenses SET is_blocked = ? WHERE id = ?', [is_blocked, id], function(err){
      if (err) return res.status(500).json({ success:false, message: err.message });
      return res.json({ success:true, message:'updated' });
    });
    return;
  }
  if (action === 'delete') {
    db.run('DELETE FROM licenses WHERE id = ?', [id], function(err){
      if (err) return res.status(500).json({ success:false, message: err.message });
      return res.json({ success:true, message:'deleted' });
    });
    return;
  }
  db.run('UPDATE licenses SET expires_at = COALESCE(?, expires_at), device_id = COALESCE(?, device_id), notes = COALESCE(?, notes) WHERE id = ?', [expires_at, device_id, notes, id], function(err){
    if (err) return res.status(500).json({ success:false, message: err.message });
    res.json({ success:true, message:'updated' });
  });
});

// Public: validate license
app.post(API_BASE + '/validate', (req, res) => {
  const key = (req.body.key || '').trim();
  const device_id = (req.body.device_id || '').trim();
  if (!key) return res.status(400).json({ success:false, message:'Missing key' });
  db.get('SELECT * FROM licenses WHERE key = ? LIMIT 1', [key], (err,row) => {
    if (err) return res.status(500).json({ success:false, message: err.message });
    if (!row) return res.status(404).json({ success:false, message:'License not found' });
    if (row.is_blocked) return res.status(403).json({ success:false, message:'Blocked' });
    if (row.expires_at && new Date(row.expires_at) < new Date()) return res.status(403).json({ success:false, message:'Expired' });
    if (row.device_id && device_id && row.device_id !== device_id) return res.status(403).json({ success:false, message:'Device mismatch' });
    if (row.device_id && !device_id) return res.status(403).json({ success:false, message:'Device required' });
    db.run('UPDATE licenses SET use_count = use_count + 1 WHERE id = ?', [row.id], (uerr) => {
      if (uerr) console.error('Increment use_count failed', uerr);
      return res.json({ success:true, message:'Valid', data: { id: row.id, key: row.key, device_id: row.device_id, expires_at: row.expires_at, use_count: row.use_count + 1 }});
    });
  });
});

// Admin stats
app.get(API_BASE + '/stats', verifyAdminJWT, (req, res) => {
  const sql = `
    SELECT
      SUM(CASE WHEN is_blocked = 0 AND (expires_at IS NULL OR expires_at > datetime('now')) THEN 1 ELSE 0 END) as active,
      SUM(CASE WHEN expires_at IS NOT NULL AND expires_at <= datetime('now') THEN 1 ELSE 0 END) as expired,
      SUM(CASE WHEN is_blocked = 1 THEN 1 ELSE 0 END) as blocked,
      COUNT(*) as total
    FROM licenses
  `;
  db.get(sql, [], (err, row) => {
    if (err) return res.status(500).json({ success:false, message: err.message });
    res.json({ success:true, stats: row });
  });
});

// Fallback
app.use((req,res)=>{
  if (req.originalUrl.startsWith(API_BASE)) {
    return res.status(404).json({ success:false, message: 'API route not found' });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, HOST, ()=> {
  console.log(`Server started at http://${HOST}:${PORT} -- API base: ${API_BASE}`);
});
